openssl req -new -x509 -keyout ps.key -out ps.pem -days 99999 -nodes -config psSSL.cnf -batch
