---
name: Feature request
about: Suggest an idea for this project
title: "[IDEA]"
labels: ''
assignees: ''

---

**Desktop, Mobile, Command Line?**
Where will this feature exist?

**Describe your idea**
A clear and concise description of what you want to happen.
