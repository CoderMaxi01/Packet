# Contributing

Perfore submitting, please agree your submission is:

* Original, public domain, MIT, BSD, or Apache licensed (non copyleft).
* If it is original, your code snippet becomes irrevocablely licensed for any use by NagleCode, and you have your own irrevocable license for any use of it (including re-gifting).

While Packet Sender's code is provided publicly as GPL, the license scheme for internal development is quite complex. Therefore, in the interset of simplicity, the above agreement is needed.
