---
name: Bug report
about: Create a report to help us improve
title: "[BUG]"
labels: ''
assignees: ''

---

#### What OS?

- [ ] Windows
- [ ] Mac
- [ ] Linux (Which distro?)
- [ ] iOS (phone or ipad?)
- [ ] Android (phone or tablet?)

#### Description of issue
